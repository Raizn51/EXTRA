import React from 'react';
import AppRoutes from './router/routes';

function App() {
  return <AppRoutes />;
}

export default App;
