import DashboardLayout from './DashboardLayout';

function CustomerDashboard() {
  return <DashboardLayout role="Customer" />;
}


export default CustomerDashboard;
