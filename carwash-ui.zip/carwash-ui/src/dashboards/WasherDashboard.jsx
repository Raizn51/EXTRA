import DashboardLayout from './DashboardLayout';

function WasherDashboard() {
  return <DashboardLayout role="Washer" />;
}

export default WasherDashboard;
