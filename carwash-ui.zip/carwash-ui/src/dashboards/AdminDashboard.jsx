import DashboardLayout from './DashboardLayout';

function AdminDashboard() {
  return <DashboardLayout role="Admin" />;
}

export default AdminDashboard;
