import React from 'react';
import { Box, Button, Typography, Stack } from '@mui/material';
import { useNavigate } from 'react-router-dom';

function HomePageNew() {
  const navigate = useNavigate();

  return (
    <Box
      sx={{
        height: '100vh',
        backgroundImage: 'url(https://images.unsplash.com/photo-1581579185169-3c46abda6b59?auto=format&fit=crop&w=1470&q=80)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        color: '#fff',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
      }}
    >
      <Typography variant="h2" sx={{ mb: 2, fontWeight: 'bold', textShadow: '2px 2px 6px rgba(0,0,0,0.7)' }}>
        i-Transform Car Wash
      </Typography>
      <Typography variant="h6" sx={{ mb: 4, textShadow: '1px 1px 4px rgba(0,0,0,0.6)' }}>
        Making Your Ride Shine Again 🚗✨
      </Typography>
      <Stack direction="row" spacing={2}>
        <Button variant="contained" color="primary" size="large" onClick={() => navigate('/login')}>
          Login
        </Button>
        <Button variant="outlined" color="inherit" size="large" onClick={() => navigate('/register')}>
          Register
        </Button>
      </Stack>
    </Box>
  );
}

export default HomePageNew;
