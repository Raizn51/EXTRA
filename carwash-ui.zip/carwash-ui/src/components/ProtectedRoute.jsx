import React from 'react';
import { Navigate } from 'react-router-dom';

const ProtectedRoute = ({ allowedRoles, children }) => {
  const token = localStorage.getItem('token');
  if (!token) return <Navigate to="/login" replace />;

  try {
    const decoded = JSON.parse(atob(token.split('.')[1]));
    const role = decoded.Role || decoded.roles?.[0]?.authority;

    console.log('Role from token:', role); // Optional debug

    return allowedRoles.includes(role)
      ? children
      : <Navigate to="/login" replace />;
  } catch (e) {
    console.error("Token decode failed:", e);
    return <Navigate to="/login" replace />;
  }
};

export default ProtectedRoute;
