import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from '../auth/Login';
import AdminDashboard from '../dashboards/AdminDashboard';
import CustomerDashboard from '../dashboards/CustomerDashboard';
import WasherDashboard from '../dashboards/WasherDashboard';
import ProtectedRoute from '../components/ProtectedRoute';
import HomePageNew from '../components/HomePageNew'; // ✅ Fixed here


function AppRoutes() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePageNew />} />
        <Route path="/login" element={<Login />} />

        <Route
          path="/admin/dashboard"
          element={
            <ProtectedRoute allowedRoles={['ADMIN']}>
              <AdminDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/customer/dashboard"
          element={
            <ProtectedRoute allowedRoles={['CUSTOMER']}>
              <CustomerDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/washer/dashboard"
          element={
            <ProtectedRoute allowedRoles={['WASHER']}>
              <WasherDashboard />
            </ProtectedRoute>
          }
        />
      </Routes>
    </Router>
  );
}

export default AppRoutes;
