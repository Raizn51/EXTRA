package com.cropdeal.userservice.entity;

public enum Role {
    ADMIN,
    FARMER,
    DEALER
}
