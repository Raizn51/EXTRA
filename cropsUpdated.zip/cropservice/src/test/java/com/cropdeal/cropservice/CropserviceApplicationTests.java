package com.cropdeal.cropservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CropserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
