package com.cropdeal.cropservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class CropserviceApplication {
	public static void main(String[] args) {
		SpringApplication.run(CropserviceApplication.class, args);
	}
}
