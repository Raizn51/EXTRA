package com.example.paymentservice.service;

import com.example.paymentservice.dto.PaymentRequest;
import com.example.paymentservice.feign.BillingClient;
import com.example.paymentservice.model.Payment;
import com.example.paymentservice.repository.PaymentRepository;
import org.junit.jupiter.api.*;
import org.mockito.*;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PaymentServiceTest {

    @Mock
    private PaymentRepository paymentRepository;

    @Mock
    private BillingClient billingClient;

    @InjectMocks
    private PaymentService paymentService;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void shouldAddPaymentWhenBillExists() {
        PaymentRequest req = new PaymentRequest(1L, 5000.0, 4000.0, 2, "1234567812345678");

        when(billingClient.isBillGenerated(1L)).thenReturn(true);

        Payment mockSaved = new Payment(10L, 9000.0, "2025-06-25T18:30", "1234567812345678", 1L);
        when(paymentRepository.save(any(Payment.class))).thenReturn(mockSaved);

        Payment result = paymentService.addPaymentFromReservation(req);

        assertNotNull(result);
        assertEquals(9000.0, result.getTotal());
        verify(paymentRepository).save(any(Payment.class));
    }

    @Test
    void shouldThrowIfBillNotFound() {
        PaymentRequest req = new PaymentRequest(2L, 5000.0, 4000.0, 3, "1111222233334444");

        when(billingClient.isBillGenerated(2L)).thenReturn(false);

        assertThrows(IllegalStateException.class, () -> paymentService.addPaymentFromReservation(req));
        verify(paymentRepository, never()).save(any());
    }
}