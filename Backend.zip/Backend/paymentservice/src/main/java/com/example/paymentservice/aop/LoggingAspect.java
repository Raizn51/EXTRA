package com.example.paymentservice.aop;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class LoggingAspect {

    @Around("execution(* com.example.paymentservice.service..*(..))")
    public Object logServiceMethods(ProceedingJoinPoint joinPoint) throws Throwable {
        String method = joinPoint.getSignature().toShortString();
        log.info("➡ Entering: {}", method);

        long start = System.currentTimeMillis();
        try {
            Object result = joinPoint.proceed();
            long duration = System.currentTimeMillis() - start;
            log.info("✅ Exiting: {} | Execution time: {} ms", method, duration);
            return result;
        } catch (Throwable ex) {
            log.error("❌ Exception in {}: {}", method, ex.getMessage(), ex);
            throw ex;
        }
    }
}