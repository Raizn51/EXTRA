package com.example.paymentservice.repository;

import com.example.paymentservice.model.Payment;
import com.example.paymentservice.model.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {

    // ✔ Used for payment history or listing all attempts
    List<Payment> findAllByReservationId(Long reservationId);

    // ✔ Used to safely fetch the most recent successful payment
    Optional<Payment> findTopByReservationIdAndStatusOrderByPayTimeDesc(Long reservationId, PaymentStatus status);
}