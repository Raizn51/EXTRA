package com.example.paymentservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "reservation")
public interface ReservationClient {
    @PutMapping("/api/v1/reservations/{reservationId}/confirm/{roomId}")
    void confirmReservation(@PathVariable Long reservationId, @PathVariable Long roomId);
}