package com.example.paymentservice.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "payments")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    private Double total;

    @NotNull
    private String payTime;

    @NotNull
    @Pattern(regexp = "\\d{16}", message = "Credit card must be 16 digits")
    private String creditCardDetails;

    private Long reservationId;

    @Enumerated(EnumType.STRING)
    private PaymentStatus status;
}