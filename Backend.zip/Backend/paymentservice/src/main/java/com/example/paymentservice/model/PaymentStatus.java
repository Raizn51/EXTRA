package com.example.paymentservice.model;

public enum PaymentStatus {
    PENDING,
    SUCCESS,
    REFUNDED
}