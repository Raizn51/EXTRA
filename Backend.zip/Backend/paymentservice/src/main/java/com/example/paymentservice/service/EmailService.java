package com.example.paymentservice.service;

import org.springframework.stereotype.Service;

@Service
public class EmailService {

    public void sendBill(String email, Long reservationId) {
        String pdfUrl = "http://yourdomain.com/bills/download/BILL-" + reservationId + ".pdf";
        System.out.println("📧 Bill sent to " + email + " → " + pdfUrl);
    }

    public void sendPaymentSuccess(String email, Double total) {
        System.out.println("✅ Payment of ₹" + total + " successful. Confirmation email sent to " + email);
    }
}