package com.example.paymentservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "billingservice")
public interface BillingClient {
    @GetMapping("/bills/confirm/{reservationId}")
    Boolean isBillGenerated(@PathVariable Long reservationId);
}