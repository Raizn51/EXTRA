package com.example.paymentservice.service;

import com.example.paymentservice.dto.PaymentRequest;
import com.example.paymentservice.dto.RoomDto;
import com.example.paymentservice.feign.BillingClient;
import com.example.paymentservice.feign.ReservationClient;
import com.example.paymentservice.feign.RoomClient;
import com.example.paymentservice.model.Payment;
import com.example.paymentservice.model.PaymentStatus;
import com.example.paymentservice.repository.PaymentRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PaymentService {

    private final PaymentRepository repository;
    private final BillingClient billingClient;
    private final ReservationClient reservationClient;
    private final RoomClient roomClient;

    public PaymentService(PaymentRepository repository,
                          BillingClient billingClient,
                          ReservationClient reservationClient,
                          RoomClient roomClient) {
        this.repository = repository;
        this.billingClient = billingClient;
        this.reservationClient = reservationClient;
        this.roomClient = roomClient;
    }

    public Payment processPayment(PaymentRequest request) {
        boolean billExists = billingClient.isBillGenerated(request.getReservationId());
        if (!billExists) {
            throw new IllegalStateException("Bill not generated for this reservation.");
        }

        boolean alreadyPaid = repository
                .findTopByReservationIdAndStatusOrderByPayTimeDesc(request.getReservationId(), PaymentStatus.SUCCESS)
                .isPresent();

        if (alreadyPaid) {
            throw new IllegalStateException("Payment already completed for this reservation.");
        }

        double total = request.getFirstNightPrice() +
                (request.getNumberOfNights() - 1) * request.getExtensionPrice();

        Payment payment = new Payment();
        payment.setReservationId(request.getReservationId());
        payment.setCreditCardDetails(request.getCreditCardDetails());
        payment.setPayTime(LocalDateTime.now().toString());
        payment.setTotal(total);
        payment.setStatus(PaymentStatus.SUCCESS);
        Payment saved = repository.save(payment);

        RoomDto room = roomClient.getAvailableRoom(request.getRoomType());
        roomClient.markRoomUnavailable(room.getId());

        reservationClient.confirmReservation(request.getReservationId(), room.getId());

        return saved;
    }

    public void refundPayment(Long reservationId) {
        Payment payment = repository
                .findTopByReservationIdAndStatusOrderByPayTimeDesc(reservationId, PaymentStatus.SUCCESS)
                .orElseThrow(() -> new RuntimeException("No successful payment found"));

        payment.setStatus(PaymentStatus.REFUNDED);
        repository.save(payment);
    }

    public List<Payment> getAllPayments() {
        return repository.findAll();
    }

    public double getTotalIncome() {
        List<Payment> all = repository.findAll();

        double success = all.stream()
                .filter(p -> p.getStatus() == PaymentStatus.SUCCESS)
                .mapToDouble(Payment::getTotal)
                .sum();

        double refunds = all.stream()
                .filter(p -> p.getStatus() == PaymentStatus.REFUNDED)
                .mapToDouble(Payment::getTotal)
                .sum();

        return success - refunds;
    }
}