package com.example.paymentservice.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentRequest {
    private Long reservationId;
    private Double firstNightPrice;
    private Double extensionPrice;
    private int numberOfNights;
    private String creditCardDetails;
    private String roomType; // needed to assign room after payment
}