package com.example.paymentservice.feign;

import com.example.paymentservice.dto.RoomDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "roomservice")
public interface RoomClient {

    @GetMapping("/room/available-room")
    RoomDto getAvailableRoom(@RequestParam String roomType);

    @PutMapping("/room/{id}/mark-unavailable")
    void markRoomUnavailable(@PathVariable Long id);
}