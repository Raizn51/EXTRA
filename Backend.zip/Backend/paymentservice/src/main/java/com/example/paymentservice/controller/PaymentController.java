package com.example.paymentservice.controller;

import com.example.paymentservice.dto.PaymentRequest;
import com.example.paymentservice.model.Payment;
import com.example.paymentservice.service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    private final PaymentService service;

    public PaymentController(PaymentService service) {
        this.service = service;
    }

    @PostMapping("/pay")
    public ResponseEntity<Payment> pay(@RequestBody PaymentRequest request) {
        return ResponseEntity.ok(service.processPayment(request));
    }

    @PutMapping("/refund/{reservationId}")
    public ResponseEntity<String> refund(@PathVariable Long reservationId) {
        service.refundPayment(reservationId);
        return ResponseEntity.ok("Refund processed.");
    }

    @GetMapping("/all")
    public ResponseEntity<List<Payment>> getAll() {
        return ResponseEntity.ok(service.getAllPayments());
    }

    @GetMapping("/income")
    public ResponseEntity<Double> getIncome() {
        return ResponseEntity.ok(service.getTotalIncome());
    }
}