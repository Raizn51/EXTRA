package com.example.guestservice.controller;

import com.example.guestservice.dto.GuestDto;
import com.example.guestservice.model.Guest;
import com.example.guestservice.service.GuestService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/guests")
public class GuestController {

    private final GuestService service;

    public GuestController(GuestService service) {
        this.service = service;
    }

    @PostMapping
    public Guest addGuest(@RequestBody Guest guest) {
        return service.addGuest(guest);
    }

    @PostMapping("/from-reservation")
    public Guest saveFromReservation(@RequestBody GuestDto guestDto) {
        return service.saveFromReservation(guestDto);
    }

    @GetMapping
    public List<Guest> getAllGuests() {
        return service.getAllGuests();
    }

    @GetMapping("/{id}")
    public Guest getGuestById(@PathVariable Long id) {
        return service.getGuestById(id);
    }

    @PutMapping("/{id}")
    public Guest updateGuest(@PathVariable Long id, @RequestBody Guest guest) {
        return service.updateGuest(id, guest);
    }

    @DeleteMapping("/{id}")
    public String deleteGuest(@PathVariable Long id) {
        service.deleteGuest(id);
        return "Guest with ID " + id + " has been deleted.";
    }
}