package com.example.guestservice.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.*;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    @Pointcut("execution(* com.example.guestservice..*(..))")
    public void logMethods() {}

    @Before("logMethods()")
    public void logBefore(JoinPoint joinPoint) {
        logger.info("➡ Entering: {} with args: {}", joinPoint.getSignature(), joinPoint.getArgs());
    }

    @AfterReturning(pointcut = "logMethods()", returning = "result")
    public void logAfter(JoinPoint joinPoint, Object result) {
        logger.info("✅ Returned from: {} with result: {}", joinPoint.getSignature(), result);
    }

    @AfterThrowing(pointcut = "logMethods()", throwing = "ex")
    public void logError(JoinPoint joinPoint, Throwable ex) {
        logger.error("❌ Exception in {}: {}", joinPoint.getSignature(), ex.getMessage());
    }
}