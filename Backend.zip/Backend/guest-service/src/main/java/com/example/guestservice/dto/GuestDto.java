package com.example.guestservice.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GuestDto {
    private Long id;
    private String memberCode;
    private String phoneNumber;
    private String company;
    private String name;
    private String email;
    private String gender;
    private String address;
}