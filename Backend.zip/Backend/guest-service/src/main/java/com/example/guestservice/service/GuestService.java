package com.example.guestservice.service;

import com.example.guestservice.dto.GuestDto;
import com.example.guestservice.exception.GuestNotFoundException;
import com.example.guestservice.model.Guest;
import com.example.guestservice.repository.GuestRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GuestService {

    private final GuestRepository repository;

    public GuestService(GuestRepository repository) {
        this.repository = repository;
    }

    public Guest addGuest(Guest guest) {
        return repository.save(guest);
    }

    public Guest saveFromReservation(GuestDto dto) {
        Guest guest = new Guest(
                dto.getId(),
                dto.getMemberCode(),
                dto.getPhoneNumber(),
                dto.getCompany(),
                dto.getName(),
                dto.getEmail(),
                dto.getGender(),
                dto.getAddress()
        );
        return repository.save(guest);
    }

    public List<Guest> getAllGuests() {
        return repository.findAll();
    }

    public Guest getGuestById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new GuestNotFoundException("Guest not found with ID: " + id));
    }

    public Guest updateGuest(Long id, Guest updated) {
        Guest guest = getGuestById(id);
        guest.setMemberCode(updated.getMemberCode());
        guest.setPhoneNumber(updated.getPhoneNumber());
        guest.setCompany(updated.getCompany());
        guest.setName(updated.getName());
        guest.setEmail(updated.getEmail());
        guest.setGender(updated.getGender());
        guest.setAddress(updated.getAddress());
        return repository.save(guest);
    }

    public void deleteGuest(Long id) {
        Guest guest = getGuestById(id);
        repository.delete(guest);
    }
}