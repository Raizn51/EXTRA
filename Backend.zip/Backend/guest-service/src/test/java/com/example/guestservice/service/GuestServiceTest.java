package com.example.guestservice.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.guestservice.exception.GuestNotFoundException;
import com.example.guestservice.model.Guest;
import com.example.guestservice.repository.GuestRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

class GuestServiceTest {

    @Mock
    private GuestRepository repository;

    @InjectMocks
    private GuestService service;

    @Test
    void testGetGuestById_Success() {
        Guest guest = new Guest(1L, "MEM123", "9876543210", "ABC Corp", "John Doe", "john@example.com", "Male", "123 Street");

        when(repository.findById(1L)).thenReturn(Optional.of(guest));

        Guest foundGuest = service.getGuestById(1L);
        assertEquals("John Doe", foundGuest.getName());
    }

    @Test
    void testGetGuestById_NotFound() {
        when(repository.findById(2L)).thenReturn(Optional.empty());

        assertThrows(GuestNotFoundException.class, () -> service.getGuestById(2L));
    }
}