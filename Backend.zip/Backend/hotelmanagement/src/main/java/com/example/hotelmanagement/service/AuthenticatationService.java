package com.example.hotelmanagement.service;

import com.example.hotelmanagement.dto.JWTAuthenticationResponse;
import com.example.hotelmanagement.dto.LoginRequest;
import com.example.hotelmanagement.entity.User;

import java.util.List;

public interface AuthenticatationService {
    User signup(User signupRequest);


    JWTAuthenticationResponse signin(LoginRequest signinRequest);

}

