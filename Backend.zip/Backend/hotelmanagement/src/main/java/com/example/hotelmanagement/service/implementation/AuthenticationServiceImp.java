package com.example.hotelmanagement.service.implementation;


import com.example.hotelmanagement.dto.JWTAuthenticationResponse;
import com.example.hotelmanagement.dto.LoginRequest;
import com.example.hotelmanagement.entity.User;
import com.example.hotelmanagement.exception.InvalidCredentialsException;
import com.example.hotelmanagement.exception.UserAlreadyExistsException;
import com.example.hotelmanagement.repository.UserRepository;
import com.example.hotelmanagement.service.JWTService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.hotelmanagement.service.AuthenticatationService;

@Service
@RequiredArgsConstructor
public class AuthenticationServiceImp implements AuthenticatationService {

    private final UserRepository authUserDAO;

    private final PasswordEncoder passwordEncoder;

    private final AuthenticationManager authenticationManager;

    private final JWTService jwtService;


    @Override
    public User signup(User signupRequest) {
        if (authUserDAO.existsByUsernameOrEmail(signupRequest.getUsername(), signupRequest.getEmail())) {
            throw new UserAlreadyExistsException("User already exists with username or email");
        }

        User authUser = new User();
        authUser.setUsername(signupRequest.getUsername());
        authUser.setFullName(signupRequest.getFullName());
        authUser.setEmail(signupRequest.getEmail());
        authUser.setRole(signupRequest.getRole());
        authUser.setPassword(passwordEncoder.encode(signupRequest.getPassword()));

        authUserDAO.save(authUser);
        return authUser;
    }

    @Override
    public JWTAuthenticationResponse signin(LoginRequest signinRequest) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(signinRequest.getUsername(), signinRequest.getPassword())
            );
        } catch (Exception e) {
            throw new InvalidCredentialsException("Invalid username/email or password");
        }

        var user = authUserDAO.findByUsername(signinRequest.getUsername())
                .orElseThrow(() -> new InvalidCredentialsException("User not found"));

        var jwt = jwtService.generateToken(user);
        JWTAuthenticationResponse response = new JWTAuthenticationResponse();
        response.setToken(jwt);
        return response;
    }

}
