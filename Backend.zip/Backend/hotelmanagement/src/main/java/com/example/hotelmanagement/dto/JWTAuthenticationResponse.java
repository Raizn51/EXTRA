package com.example.hotelmanagement.dto;

import lombok.Data;

@Data
public class JWTAuthenticationResponse {

    private String token;

}