package com.example.hotelmanagement.controller;

import com.example.hotelmanagement.dto.LoginRequest;
import com.example.hotelmanagement.entity.User;
import com.example.hotelmanagement.repository.UserRepository;
import com.example.hotelmanagement.service.AuthenticatationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/v1")
public class AuthController {

    private final AuthenticatationService authenticatationService;
    public AuthController( AuthenticatationService authenticatationService) {
        this.authenticatationService = authenticatationService;
    }

    @PostMapping("/signup")
    public ResponseEntity<String> signup(@RequestBody User user) {
        authenticatationService.signup(user);
        return ResponseEntity.ok("User registered");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {

        return ResponseEntity.ok(authenticatationService.signin(req));
    }  
}