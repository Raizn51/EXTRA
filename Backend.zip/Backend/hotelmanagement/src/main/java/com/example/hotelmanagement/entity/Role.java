package com.example.hotelmanagement.entity;

public enum Role {
    OWNER,
    MANAGER,
    RECEPTIONIST
}