package com.example.staffservice.controller;

import com.example.staffservice.model.Staff;
import com.example.staffservice.service.StaffService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/staff")
public class StaffController {
    private final StaffService service;

    public StaffController(StaffService service) {
        this.service = service;
    }

    // Create Staff Member
    @PostMapping
    public Staff addStaff(@RequestBody Staff staff) {
        return service.addStaff(staff);
    }

    // Read All Staff Members
    @GetMapping
    public List<Staff> getAllStaff() {
        return service.getAllStaff();
    }

    // Read Staff Member by ID
    @GetMapping("/{id}")
    public Staff getStaffById(@PathVariable Long id) {
        return service.getStaffById(id);
    }

    // Update Staff Member
    @PutMapping("/{id}")
    public Staff updateStaff(@PathVariable Long id, @RequestBody Staff staff) {
        return service.updateStaff(id, staff);
    }

    // Delete Staff Member
    @DeleteMapping("/{id}")
    public String deleteStaff(@PathVariable Long id) {
        service.deleteStaff(id);
        return "Staff member with ID " + id + " has been successfully deleted.";
    }
}