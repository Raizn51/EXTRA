package com.example.staffservice.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "staff_members")
public class Staff {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String code;
    private String employeeName;
    private String employeeAddress;
    private String NIC;
    private double salary;
    private int age;

    @Enumerated(EnumType.STRING)
    private Role occupation;

    private String email;
}