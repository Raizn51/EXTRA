package com.example.staffservice.model;

public enum Role
{
    OWNER,
    RECEPTIONIST,
    MANAGER
}
