package com.example.staffservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.staffservice.model.Staff;

public interface StaffRepository extends JpaRepository<Staff, Long> {
}