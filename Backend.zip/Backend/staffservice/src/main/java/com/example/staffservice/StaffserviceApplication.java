package com.example.staffservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StaffserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StaffserviceApplication.class, args);
	}

}
