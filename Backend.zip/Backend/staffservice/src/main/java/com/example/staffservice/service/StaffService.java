package com.example.staffservice.service;

import com.example.staffservice.exception.StaffNotFoundException;
import com.example.staffservice.model.Staff;
import com.example.staffservice.repository.StaffRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class StaffService {
    private final StaffRepository repository;

    public StaffService(StaffRepository repository) {
        this.repository = repository;
    }

    // Create Staff Member
    public Staff addStaff(Staff staff) {
        return repository.save(staff);
    }

    // Read All Staff Members
    public List<Staff> getAllStaff() {
        return repository.findAll();
    }

    // Read Staff Member by ID
    public Staff getStaffById(Long id) {
        return repository.findById(id).orElseThrow(() ->
                new StaffNotFoundException("Staff member not found with ID: " + id));
    }

    // Update Staff Member
    public Staff updateStaff(Long id, Staff updatedStaff) {
        Staff existingStaff = repository.findById(id)
                .orElseThrow(() -> new StaffNotFoundException("Staff member not found with ID: " + id));

        existingStaff.setCode(updatedStaff.getCode());
        existingStaff.setEmployeeName(updatedStaff.getEmployeeName());
        existingStaff.setEmployeeAddress(updatedStaff.getEmployeeAddress());
        existingStaff.setNIC(updatedStaff.getNIC());
        existingStaff.setSalary(updatedStaff.getSalary());
        existingStaff.setAge(updatedStaff.getAge());
        existingStaff.setOccupation(updatedStaff.getOccupation());
        existingStaff.setEmail(updatedStaff.getEmail());

        return repository.save(existingStaff);
    }

    // Delete Staff Member
    public void deleteStaff(Long id) {
        Staff staff = repository.findById(id)
                .orElseThrow(() -> new StaffNotFoundException("Staff member not found with ID: " + id));
        repository.delete(staff);
    }
}