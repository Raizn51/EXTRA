package com.example.staffservice.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.staffservice.exception.StaffNotFoundException;
import com.example.staffservice.model.Staff;
import com.example.staffservice.repository.StaffRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.Optional;

class StaffServiceTest {

    @Mock
    private StaffRepository repository;

    @InjectMocks
    private com.example.staffservice.service.StaffRepository service;

    @Test
    void testGetStaffById_Success() {
        Staff staff = new Staff(1L, "EMP123", "John Doe", "Street 123", "NIC456789", 50000.0, 30, "Manager", "john@example.com");

        when(repository.findById(1L)).thenReturn(Optional.of(staff));

        Staff foundStaff = service.getStaffById(1L);
        assertEquals("John Doe", foundStaff.getEmployeeName());
    }

    @Test
    void testGetStaffById_NotFound() {
        when(repository.findById(2L)).thenReturn(Optional.empty());

        assertThrows(StaffNotFoundException.class, () -> service.getStaffById(2L));
    }
}