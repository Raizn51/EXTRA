package com.example.api_gateway;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGatewayApplication {

	private static final Logger log = LoggerFactory.getLogger(ApiGatewayApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayApplication.class, args);
	}

	@PostConstruct
	public void onStart() {
		log.info("✅ ApiGatewayApplication started successfully.");
		System.out.println("✅ ApiGatewayApplication started successfully.");
	}

	@PreDestroy
	public void onShutdown() {
		log.info("🛑 ApiGatewayApplication is shutting down.");
		System.out.println("🛑 ApiGatewayApplication is shutting down.");
	}
}
