package com.example.roomservice.service;

import com.example.roomservice.dto.RoomDto;
import com.example.roomservice.exception.RoomNotFoundException;
import com.example.roomservice.model.Room;
import com.example.roomservice.repository.RoomRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RoomServiceTest {

    @Mock
    private RoomRepository repository;

    @InjectMocks
    private RoomService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getAvailableRoomByType_shouldReturnRoom() {
        Room room = new Room(1L, "A101", "STANDARD", true);
        when(repository.findAllByRoomType("STANDARD")).thenReturn(List.of(room));

        RoomDto result = service.getAvailableRoomByType("STANDARD");

        assertNotNull(result);
        assertEquals("A101", result.getRoomNumber());
    }

    @Test
    void getAvailableRoomByType_shouldThrowIfNotAvailable() {
        when(repository.findAllByRoomType("DELUXE")).thenReturn(List.of());

        assertThrows(RoomNotFoundException.class,
                () -> service.getAvailableRoomByType("DELUXE"));
    }

    @Test
    void markUnavailable_shouldUpdateRoom() {
        Room room = new Room(2L, "B202", "DELUXE", true);
        when(repository.findById(2L)).thenReturn(Optional.of(room));

        service.markUnavailable(2L);

        assertFalse(room.isAvailable());
        verify(repository).save(room);
    }

    @Test
    void markUnavailable_shouldThrowIfMissing() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(RoomNotFoundException.class, () -> service.markUnavailable(99L));
    }
}