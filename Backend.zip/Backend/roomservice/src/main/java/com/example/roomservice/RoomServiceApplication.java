package com.example.roomservice;

import com.example.roomservice.model.Room;
import com.example.roomservice.repository.RoomRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableFeignClients(basePackages = "com.example.roomservice.feign")
public class RoomServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(RoomServiceApplication.class, args);
    }

    @Bean
    CommandLineRunner preload(RoomRepository repo) {
        return args -> {
            if (repo.count() >= 30) return;
            for (int i = 1; i <= 10; i++) {
                repo.save(new Room(null, "S" + i, "STANDARD", true));
                repo.save(new Room(null, "D" + i, "DELUXE", true));
                repo.save(new Room(null, "SU" + i, "SUITE", true));
            }
        };
    }
}