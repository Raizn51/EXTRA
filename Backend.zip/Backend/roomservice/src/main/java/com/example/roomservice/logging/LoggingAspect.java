package com.example.roomservice.logging;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    @Pointcut("execution(* com.example.roomservice..*(..))")
    public void roomServiceLayer() {}

    @Before("roomServiceLayer()")
    public void logBefore(JoinPoint joinPoint) {
        logger.info("➡️ Entering: {}() with arguments = {}", joinPoint.getSignature().getName(), joinPoint.getArgs());
    }

    @AfterReturning(pointcut = "roomServiceLayer()", returning = "result")
    public void logAfterReturning(JoinPoint joinPoint, Object result) {
        logger.info("✅ Returned from: {}() with result = {}", joinPoint.getSignature().getName(), result);
    }

    @AfterThrowing(pointcut = "roomServiceLayer()", throwing = "ex")
    public void logException(JoinPoint joinPoint, Throwable ex) {
        logger.error("❌ Exception in {}(): {}", joinPoint.getSignature().getName(), ex.getMessage());
    }
}