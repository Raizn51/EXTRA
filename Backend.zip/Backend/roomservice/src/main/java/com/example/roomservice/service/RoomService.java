package com.example.roomservice.service;

import com.example.roomservice.dto.RoomDto;
import com.example.roomservice.exception.RoomNotFoundException;
import com.example.roomservice.model.Room;
import com.example.roomservice.repository.RoomRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RoomService {

    private final RoomRepository repository;

    public RoomService(RoomRepository repository) {
        this.repository = repository;
    }

    public RoomDto getAvailableRoomByType(String roomType) {
        return repository.findAllByRoomType(roomType).stream()
                .filter(Room::isAvailable)
                .findFirst()
                .map(room -> new RoomDto(room.getId(), room.getRoomNumber(), room.getRoomType(), true))
                .orElseThrow(() -> new RoomNotFoundException("No available room of type: " + roomType));
    }

    public void markUnavailable(Long id) {
        Room room = repository.findById(id)
                .orElseThrow(() -> new RoomNotFoundException("Room not found with ID: " + id));
        room.setAvailable(false);
        repository.save(room);
    }

    public List<RoomDto> getAllRooms() {
        return repository.findAll().stream()
                .map(room -> new RoomDto(room.getId(), room.getRoomNumber(), room.getRoomType(), room.isAvailable()))
                .collect(Collectors.toList());
    }

    public void addRoom(Room room) {
        repository.save(room);
    }

    public void updateRoom(Long id, Room updated) {
        Room room = repository.findById(id)
                .orElseThrow(() -> new RoomNotFoundException("Room not found with ID: " + id));
        room.setRoomNumber(updated.getRoomNumber());
        room.setRoomType(updated.getRoomType());
        room.setAvailable(updated.isAvailable());
        repository.save(room);
    }

    public void deleteRoom(Long id) {
        repository.deleteById(id);
    }
}