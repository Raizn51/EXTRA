package com.example.roomservice.controller;

import com.example.roomservice.dto.RoomDto;
import com.example.roomservice.model.Room;
import com.example.roomservice.service.RoomService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/room")
public class RoomController {

    private final RoomService service;

    public RoomController(RoomService service) {
        this.service = service;
    }

    @GetMapping("/available-room")
    public RoomDto getAvailableRoom(@RequestParam String roomType) {
        return service.getAvailableRoomByType(roomType);
    }

    @PutMapping("/{id}/mark-unavailable")
    public void markUnavailable(@PathVariable Long id) {
        service.markUnavailable(id);
    }

    @GetMapping
    public List<RoomDto> getAllRooms() {
        return service.getAllRooms();
    }

    @PostMapping
    public void addRoom(@RequestBody Room room) {
        service.addRoom(room);
    }

    @PutMapping("/{id}")
    public void updateRoom(@PathVariable Long id, @RequestBody Room room) {
        service.updateRoom(id, room);
    }

    @DeleteMapping("/{id}")
    public void deleteRoom(@PathVariable Long id) {
        service.deleteRoom(id);
    }
}