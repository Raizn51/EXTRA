package com.example.roomservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class RoomAvailabilityResponse {
    private String roomType;
    private boolean available;
    private List<String> unavailableRooms;
}