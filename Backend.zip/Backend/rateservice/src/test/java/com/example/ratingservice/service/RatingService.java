package com.example.ratingservice.service;

import com.example.ratingservice.model.Rating;
import com.example.ratingservice.repository.RatingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RatingService {

    private static final Logger log = LoggerFactory.getLogger(RatingService.class);
    private final RatingRepository repository;

    public RatingService(RatingRepository repository) {
        this.repository = repository;
    }

    public Rating submitRating(Rating rating) {
        log.info("Saving rating: {} stars", rating.getStars());
        if (rating.getStars() < 1 || rating.getStars() > 5) {
            throw new IllegalArgumentException("Stars must be between 1 and 5");
        }
        return repository.save(rating);
    }

    public List<Rating> getAllRatings() {
        log.info("Fetching all ratings");
        return repository.findAll();
    }

    public double getAverageRating() {
        double avg = repository.findAll().stream()
                .mapToInt(Rating::getStars)
                .average()
                .orElse(0.0);
        log.info("Average rating calculated: {}", avg);
        return avg;
    }
}