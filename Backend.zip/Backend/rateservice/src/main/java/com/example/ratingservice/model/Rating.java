package com.example.ratingservice.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "ratings")
public class Rating {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Min(1)
    @Max(5)
    @NotNull
    private Integer stars;

    private String comment;

    // Getters and Setters
    public Long getId() { return id; }
    public Integer getStars() { return stars; }
    public String getComment() { return comment; }

    public void setId(Long id) { this.id = id; }
    public void setStars(Integer stars) { this.stars = stars; }
    public void setComment(String comment) { this.comment = comment; }
}