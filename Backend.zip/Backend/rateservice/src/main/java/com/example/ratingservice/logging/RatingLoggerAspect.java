package com.example.ratingservice.logging;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class RatingLoggerAspect {

    private static final Logger log = LoggerFactory.getLogger(RatingLoggerAspect.class);

    // Pointcut for service methods
    @Pointcut("execution(* com.example.ratingservice.service.*.*(..))")
    public void serviceLayer() {}

    // Log before method execution
    @Before("serviceLayer()")
    public void logBefore(JoinPoint joinPoint) {
        log.info("➡ Entering: {} | Args: {}", joinPoint.getSignature(), joinPoint.getArgs());
    }

    // Log after successful return
    @AfterReturning(pointcut = "serviceLayer()", returning = "result")
    public void logAfterReturning(JoinPoint joinPoint, Object result) {
        log.info("✅ Returned from: {} | Result: {}", joinPoint.getSignature(), result);
    }

    // Log if exception is thrown
    @AfterThrowing(pointcut = "serviceLayer()", throwing = "ex")
    public void logAfterThrowing(JoinPoint joinPoint, Throwable ex) {
        log.error("❌ Exception in: {} | Error: {}", joinPoint.getSignature(), ex.getMessage());
    }
}