package com.example.ratingservice.controller;

import com.example.ratingservice.model.Rating;
import com.example.ratingservice.service.RatingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ratings")
public class RatingController {

    private final RatingService service;

    public RatingController(RatingService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Rating> submitRating(@RequestBody Rating rating) {
        return ResponseEntity.ok(service.submitRating(rating));
    }

    @GetMapping
    public ResponseEntity<List<Rating>> getAllRatings() {
        return ResponseEntity.ok(service.getAllRatings());
    }

    @GetMapping("/average")
    public ResponseEntity<Double> getAverageRating() {
        return ResponseEntity.ok(service.getAverageRating());
    }
}