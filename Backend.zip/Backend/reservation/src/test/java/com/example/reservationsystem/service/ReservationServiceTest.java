package com.example.reservationsystem.service;

import com.example.reservationsystem.dto.RoomDto;
import com.example.reservationsystem.feign.RoomClient;
import com.example.reservationsystem.model.Reservation;
import com.example.reservationsystem.repository.ReservationRepository;
import org.junit.jupiter.api.*;
import org.mockito.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ReservationServiceTest {

    @InjectMocks
    private ReservationService service;

    @Mock
    private RoomClient roomClient;

    @Mock
    private ReservationRepository repository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testHandleReservation_WithAvailableRoom() {
        Reservation request = new Reservation();
        request.setGuestId(1L);
        request.setCheckInDate(LocalDate.now());
        request.setCheckOutDate(LocalDate.now().plusDays(2));
        request.setRoomType("DELUXE");

        RoomDto room = new RoomDto(101L, "B12", "DELUXE", true);

        when(roomClient.getAvailableRoom("DELUXE")).thenReturn(room);
        when(repository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        String response = service.handleReservation(request);

        assertTrue(response.contains("Room of type DELUXE allocated: B12"));
        verify(roomClient).markRoomUnavailable(101L);
        verify(repository).save(any());
    }

    @Test
    void testGetReservationById_Found() {
        Reservation res = new Reservation();
        res.setId(1L);

        when(repository.findById(1L)).thenReturn(Optional.of(res));

        Reservation result = service.getReservationById(1L);
        assertEquals(1L, result.getId());
    }

    @Test
    void testGetReservationById_NotFound() {
        when(repository.findById(anyLong())).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> service.getReservationById(999L));
        assertEquals("Reservation not found with ID: 999", ex.getMessage());
    }
}