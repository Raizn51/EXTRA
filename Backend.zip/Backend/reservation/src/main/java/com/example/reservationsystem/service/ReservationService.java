package com.example.reservationsystem.service;

import com.example.reservationsystem.dto.GuestDto;
import com.example.reservationsystem.dto.RoomDto;
import com.example.reservationsystem.feign.BillingClient;
import com.example.reservationsystem.feign.GuestClient;
import com.example.reservationsystem.feign.RoomClient;
import com.example.reservationsystem.model.Reservation;
import com.example.reservationsystem.model.ReservationStatus;
import com.example.reservationsystem.repository.ReservationRepository;
import org.springframework.stereotype.Service;

import java.time.temporal.ChronoUnit;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
public class ReservationService {

    private final ReservationRepository repository;
    private final RoomClient roomClient;
    private final GuestClient guestClient;
    private final BillingClient billingClient;
    private final EmailService emailService;

    public ReservationService(ReservationRepository repository,
                              RoomClient roomClient,
                              GuestClient guestClient,
                              BillingClient billingClient,
                              EmailService emailService) {
        this.repository = repository;
        this.roomClient = roomClient;
        this.guestClient = guestClient;
        this.billingClient = billingClient;
        this.emailService = emailService;
    }

    public String handleReservation(Reservation reservation) {
        GuestDto guest = new GuestDto(
                reservation.getGuestId(), reservation.getMemberCode(),
                reservation.getPhoneNumber(), reservation.getCompany(),
                reservation.getName(), reservation.getEmail(),
                reservation.getGender(), reservation.getAddress()
        );
        guestClient.saveGuest(guest);

        reservation.setCode("RES-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        reservation.setStatus(ReservationStatus.PENDING_PAYMENT);
        int nights = (int) ChronoUnit.DAYS.between(reservation.getCheckInDate(), reservation.getCheckOutDate());
        reservation.setNumberOfNights(nights);
        Reservation saved = repository.save(reservation);

        billingClient.generateBill(saved.getId());
        emailService.sendPaymentRequest(saved.getEmail(), saved.getId());

        return "Reservation created. Guest saved. Bill generated. Waiting for payment.";
    }

    public void confirmReservation(Long reservationId, Long roomId) {
        Reservation reservation = getReservationById(reservationId);
        reservation.setStatus(ReservationStatus.CONFIRMED);
        reservation.setRoomId(roomId);
        roomClient.markRoomUnavailable(roomId);
        repository.save(reservation);
    }

    public void cancelReservation(Long id) {
        Reservation reservation = getReservationById(id);
        reservation.setStatus(ReservationStatus.CANCELLED);
        guestClient.deleteGuest(reservation.getGuestId());
        repository.save(reservation);
    }

    public List<Reservation> getAllReservations() {
        return repository.findAll();
    }

    public Reservation getReservationById(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Not found"));
    }

    public void addRoom(RoomDto roomDto) {
        roomClient.addRoom(roomDto);
    }

    public void updateRoom(Long id, RoomDto roomDto) {
        roomClient.updateRoom(id, roomDto);
    }

    public void deleteRoom(Long id) {
        roomClient.deleteRoom(id);
    }

    public List<RoomDto> getAllRooms() {
        return roomClient.getAllRooms();
    }
}