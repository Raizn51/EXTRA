package com.example.reservationsystem.controller;

import com.example.reservationsystem.dto.RoomDto;
import com.example.reservationsystem.model.Reservation;
import com.example.reservationsystem.service.ReservationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/reservations")
public class ReservationController {

    private final ReservationService service;

    public ReservationController(ReservationService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<String> createReservation(@RequestBody Reservation reservation) {
        return ResponseEntity.ok(service.handleReservation(reservation));
    }

    @PutMapping("/{reservationId}/confirm/{roomId}")
    public ResponseEntity<String> confirmReservation(@PathVariable Long reservationId, @PathVariable Long roomId) {
        service.confirmReservation(reservationId, roomId);
        return ResponseEntity.ok("Reservation confirmed and room assigned.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> cancelReservation(@PathVariable Long id) {
        service.cancelReservation(id);
        return ResponseEntity.ok("Reservation cancelled.");
    }

    @GetMapping
    public ResponseEntity<List<Reservation>> getAllReservations() {
        return ResponseEntity.ok(service.getAllReservations());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Reservation> getReservation(@PathVariable Long id) {
        return ResponseEntity.ok(service.getReservationById(id));
    }

    @PostMapping("/rooms")
    public ResponseEntity<String> addRoom(@RequestBody RoomDto roomDto) {
        service.addRoom(roomDto);
        return ResponseEntity.ok("Room added.");
    }

    @PutMapping("/rooms/{id}")
    public ResponseEntity<String> updateRoom(@PathVariable Long id, @RequestBody RoomDto roomDto) {
        service.updateRoom(id, roomDto);
        return ResponseEntity.ok("Room updated.");
    }

    @DeleteMapping("/rooms/{id}")
    public ResponseEntity<String> deleteRoom(@PathVariable Long id) {
        service.deleteRoom(id);
        return ResponseEntity.ok("Room deleted.");
    }

    @GetMapping("/rooms")
    public ResponseEntity<List<RoomDto>> getAllRooms() {
        return ResponseEntity.ok(service.getAllRooms());
    }
}