package com.example.reservationsystem.service;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    public void sendPaymentRequest(String guestEmail, Long reservationId) {
        // Simulate sending an email
        System.out.println("📧 Sending payment link to " + guestEmail + " for reservation ID: " + reservationId);
    }
}