package com.example.reservationsystem.feign;

import com.example.reservationsystem.dto.RoomDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "roomservice")
public interface RoomClient {

    @GetMapping("/room/available-room")
    RoomDto getAvailableRoom(@RequestParam String roomType);

    @PutMapping("/room/{id}/mark-unavailable")
    void markRoomUnavailable(@PathVariable Long id);

    @GetMapping("/room")
    List<RoomDto> getAllRooms();

    @PostMapping("/room")
    void addRoom(@RequestBody RoomDto roomDto);

    @PutMapping("/room/{id}")
    void updateRoom(@PathVariable Long id, @RequestBody RoomDto roomDto);

    @DeleteMapping("/room/{id}")
    void deleteRoom(@PathVariable Long id);
}