package com.example.reservationsystem.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RoomStatus {
    private Long roomId;
    private String roomNumber;
    private boolean available;
}