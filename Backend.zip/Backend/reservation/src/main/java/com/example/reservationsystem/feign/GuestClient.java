package com.example.reservationsystem.feign;

import com.example.reservationsystem.dto.GuestDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "guest-service") // 'guest-service' must match the GuestService's application name
public interface GuestClient {
    @PostMapping("/guests/from-reservation")
    GuestDto saveGuest(@RequestBody GuestDto guest);

    @DeleteMapping("/guests/{id}")
    void deleteGuest(@PathVariable Long id);
}