package com.example.reservationsystem.model;

public enum ReservationStatus {
    PENDING_PAYMENT,
    CONFIRMED,
    CANCELLED
}