package com.example.billingservice.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import com.example.billingservice.model.Bill;
import com.example.billingservice.repository.BillRepository;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class BillServiceTest {

    @Mock
    private BillRepository billRepository;

    @InjectMocks
    private BillService billService;

    @Test
    public void testIssueBill() {
        Bill bill = new Bill();
        bill.setBillingNo("BILL123");
        bill.setQuantity(2);
        bill.setPrice(100.0);
        bill.setTaxes(10.0);
        bill.setDate("2025-06-05");
        bill.setServices("Room Service");
        bill.setUnit("Nights");

        Mockito.when(billRepository.save(any(Bill.class))).thenReturn(bill);

        Bill createdBill = billService.issueBill(bill);

        assertNotNull(createdBill);
        assertEquals("BILL123", createdBill.getBillingNo());
    }
}