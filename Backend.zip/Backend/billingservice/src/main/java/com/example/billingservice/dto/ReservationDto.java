package com.example.billingservice.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class ReservationDto {
    private Long id;
    private String code;
    private String name;
    private String roomType;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private String email;
    private String phoneNumber;
}