package com.example.billingservice.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "bills")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Bill {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "billing_no", nullable = false)
    private String billingNo;

    private String guestName;
    private String roomType;
    private String checkInDate;
    private String checkOutDate;
    private int nights;
    private double amount;
    private double tax;

    @Column(name = "bill_date")
    private String billDate;

    @Column(name = "pdf_url")
    private String pdfUrl;

    @Column(name = "reservation_id", nullable = false)
    private Long reservationId; // Required for payment confirmation check
}