package com.example.billingservice.service;

import com.example.billingservice.dto.ReservationDto;
import com.example.billingservice.feign.ReservationClient;
import com.example.billingservice.model.Bill;
import com.example.billingservice.repository.BillRepository;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

@Service
public class BillService {

    private final BillRepository repo;
    private final ReservationClient reservationClient;

    public BillService(BillRepository repo, ReservationClient reservationClient) {
        this.repo = repo;
        this.reservationClient = reservationClient;
    }

    @Transactional
    public Bill generateBill(Long reservationId) {
        ReservationDto r = reservationClient.getReservation(reservationId);
        int nights = (int) ChronoUnit.DAYS.between(r.getCheckInDate(), r.getCheckOutDate());

        double rate = switch (r.getRoomType().toUpperCase()) {
            case "DELUXE" -> 4000.0;
            case "SUITE" -> 6000.0;
            default -> 2500.0;
        };

        double amount = nights * rate;
        double tax = Math.round(amount * 0.12 * 100.0) / 100.0;
        String billNo = "BILL-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        String pdfName = billNo + ".pdf";
        String pdfPath = "bills/" + pdfName;

        // Ensure directory exists before writing PDF
        File billDir = new File("bills");
        if (!billDir.exists()) {
            boolean created = billDir.mkdirs();
            if (!created) {
                throw new RuntimeException("Failed to create directory for bills");
            }
        }

        Bill bill = new Bill();
        bill.setBillingNo(billNo);
        bill.setGuestName(r.getName());
        bill.setRoomType(r.getRoomType());
        bill.setCheckInDate(r.getCheckInDate().toString());
        bill.setCheckOutDate(r.getCheckOutDate().toString());
        bill.setNights(nights);
        bill.setAmount(amount);
        bill.setTax(tax);
        bill.setBillDate(LocalDate.now().toString());
        bill.setPdfUrl("/bills/download/" + pdfName);
        bill.setReservationId(reservationId); // ✅ This was missing
        generatePdf(pdfPath, bill);
        return repo.save(bill);
    }

    private void generatePdf(String path, Bill b) {
        try {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(path));
            document.open();

            Font title = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20);
            document.add(new Paragraph("Hotel Reservation Bill", title));
            document.add(new Paragraph(" "));
            document.add(new Paragraph("Billing No: " + b.getBillingNo()));
            document.add(new Paragraph("Guest: " + b.getGuestName()));
            document.add(new Paragraph("Room Type: " + b.getRoomType()));
            document.add(new Paragraph("Check-In: " + b.getCheckInDate()));
            document.add(new Paragraph("Check-Out: " + b.getCheckOutDate()));
            document.add(new Paragraph("Nights Stayed: " + b.getNights()));
            document.add(new Paragraph("Amount: ₹" + b.getAmount()));
            document.add(new Paragraph("Tax (12%): ₹" + b.getTax()));
            document.add(new Paragraph("Total: ₹" + (b.getAmount() + b.getTax())));
            document.add(new Paragraph("Bill Date: " + b.getBillDate()));

            document.close();
        } catch (Exception e) {
            throw new RuntimeException("PDF generation failed", e);
        }
    }
}