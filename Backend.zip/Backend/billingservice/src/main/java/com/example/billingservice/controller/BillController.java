package com.example.billingservice.controller;

import com.example.billingservice.model.Bill;
import com.example.billingservice.service.BillService;
import com.example.billingservice.repository.BillRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/bills")
public class BillController {

    private final BillService billService;
    private final BillRepository billRepository;

    public BillController(BillService billService, BillRepository billRepository) {
        this.billService = billService;
        this.billRepository = billRepository;
    }

    // ✅ Used by ReservationService or Postman to generate bill from reservation
    @PostMapping("/generate/{reservationId}")
    public ResponseEntity<Bill> generateBill(@PathVariable Long reservationId) {
        Bill bill = billService.generateBill(reservationId);
        return ResponseEntity.ok(bill);
    }

    // ✅ Used by PaymentService to confirm if bill has been generated
    @GetMapping("/confirm/{reservationId}")
    public ResponseEntity<Boolean> confirmBill(@PathVariable Long reservationId) {
        boolean exists = billRepository.existsByReservationId(reservationId);
        return ResponseEntity.ok(exists);
    }
}