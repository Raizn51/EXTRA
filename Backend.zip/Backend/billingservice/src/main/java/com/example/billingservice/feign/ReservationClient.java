package com.example.billingservice.feign;

import com.example.billingservice.dto.ReservationDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "reservation")
public interface ReservationClient {
    @GetMapping("/api/v1/reservations/{id}")
    ReservationDto getReservation(@PathVariable Long id);
}